//TIPA Dan-Dumitru gr343C3
#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#include "TCoada.h"
#include "TStiva.h"

#define MAX 10000

typedef struct {

	int time;
	int id;
	int priority;
	int executed;
	int th_id;

	
} Task;

typedef struct{
int th_id;
int task_id;
}Thread;

//returnez threadul id
int returnthread(void*s,int id,int N){
void *stemp=InitS(DimES(s),MAX);
  void *el=malloc(DimES(s));
  
  int ok=0;

  while(!VidaS(s)){

    Pop(s,el);

    	if(((Thread*)el)->th_id==id)
   	 ok=((Thread*)el)->task_id;
   
    Push(stemp,el);

  }
  while(!VidaS(stemp)){

    Pop(stemp,el);
   
    Push(s,el);

  }
  free(el);
  
  return ok;
}

int getmaxid(int v[],int n){
	int max=0;
	int i;
	for( i=0;i<n;i++){
		if(v[i]>max)
			max=v[i];
	}
	return max;

}

//functie cu care aflu primul id valabil
//imi fac un vector de id-uri si dupa gasesc cel mai mic id negasit
//daca nu sa gasit un id atunci caut cel mai mare id si returnez acel id+1
int getFirstId(void *c,int n,void*c1){

  void *stemp=InitQ(DimEQ(c),MAX);
  void *stemp1=InitQ(DimEQ(c1),MAX);
  int v[MAX];
  int i;
  for( i=0;i<NrEQ(c)+NrEQ(c1);i++){
  	v[i]=-1;}
  void *el=malloc(DimEQ(c));
  int id=1;
  while(!VidaQ(c)){

    ExtrQ(c,el);
    v[id-1]=((Task*)el)->id;
    id++;
    
    IntrQ(stemp,el);

  }

  ConcatQ(c,stemp);

  while(!VidaQ(c1)){

    ExtrQ(c1,el);
    v[id-1]=((Task*)el)->id;
    id++;

    IntrQ(stemp1,el);

  }
  free(el);
  ConcatQ(c1,stemp1);

 int id1=id;
 int j;
 for( j=1;j<=id1;j++){
 	int ok=0;
  	id=j;
  
  for( i=0;i<NrEQ(c)+NrEQ(c1);i++){
  	if(v[i]==-1)
  		continue;
  	if(j == v[i]){
  		ok=1;
  		break;
  	}

  }
  if(ok==0)
  	return id;

}
  
  
  return getmaxid(v,NrEQ(c)+NrEQ(c1))+1;
}




int checktask(void*c,int id){
  void *qtemp=InitQ(DimEQ(c),MAX);
  void *el=malloc(DimEQ(c));
  int ok=0;
  while(!VidaQ(c)){
    ExtrQ(c,el);
   	if(id == ((Task*)el)->id)
      ok= ((Task*)el)->time;
    IntrQ(qtemp,el);

  }

  ConcatQ(c,qtemp);
  return ok;
}
//functie care verific daca se afla id-ul in coada , daca da salvez primul timp executat
int checktask3(void*c,int id){
  void *qtemp=InitQ(DimEQ(c),MAX);
  void *el=malloc(DimEQ(c));
  int ok=0,ok1=0;
  while(!VidaQ(c)){
    ExtrQ(c,el);
   	if(id == ((Task*)el)->id && ok1==0){
	      ok= ((Task*)el)->executed;
	      ok1=1;
   	}
    IntrQ(qtemp,el);

  }

  ConcatQ(c,qtemp);
  return ok;
}



int compTask(void*el1,void*el2){
	
	if( ((Task*)el1)->priority > ((Task*)el2)->priority ){
		
		return 1;
	}

	else if( ((Task*)el1)->priority == ((Task*)el2)->priority  && ((Task*)el1)->time < ((Task*)el2)->time) 
		return 1;

	else if ( ((Task*)el1)->priority == ((Task*)el2)->priority  && ((Task*)el1)->time == ((Task*)el2)->time &&((Task*)el1)->id < ((Task*)el2)->id  )
		return 1 ;
	 return -1;
	

} 
//inserez sortat in coada dupa functia de inserare compTask
void insertsort(void* q1,void*aux){
	

  if(NrEQ(q1)==0){
  
  	IntrQ(q1,aux);
  	return;
  }

void *qtemp=InitQ(DimEQ(q1),MAX);
void *el=malloc(DimEQ(q1));
void *ae=malloc(DimEQ(q1));
PrimQ(q1,ae);

if(compTask(aux,ae)==1){
	

  IntrQ(qtemp,aux);

while(!VidaQ(q1)){
    ExtrQ(q1,el);
    
	 

IntrQ(qtemp,el);
}
ConcatQ(q1,qtemp);
}

else{

	PrimQ(q1,el);
	
	
	while(compTask(el,aux)==1 && !VidaQ(q1)){
		
		ExtrQ(q1,el);
		
		IntrQ(qtemp,el);
		PrimQ(q1,el);
		
	}
	IntrQ(qtemp,aux);
	while(!VidaQ(q1)){

    ExtrQ(q1,el);
   
	 IntrQ(qtemp,el);
}
while(!VidaQ(qtemp)){


    ExtrQ(qtemp,el);
    
	 IntrQ(q1,el);
}




}


}


//scot elementul care are asignat taskul id
void Popspecial(void*s,int id){
	

  void *stemp=InitS(DimES(s),MAX);
  void *el=malloc(DimES(s));

 
  while(!VidaS(s)){


    Pop(s,el);
    if(((Thread*)el)->task_id != id)
    	Push(stemp,el);

  }
  while(!VidaS(stemp)){


    Pop(stemp,el);
   
    Push(s,el);

  }
  free(el);
 
  

}
//caut ultimul thread care nu are un task asignat
int PrimulThvalabil(void*s,int N){
	void *stemp=InitS(DimES(s),MAX);
  void *el=malloc(DimES(s));
  
int id=0;
 
  while(!VidaS(s)){

    Pop(s,el);
   if( (((Thread*)el)->task_id) )
   	
    id=((Thread*)el)->th_id;
    
    	Push(stemp,el);

  }

   while(!VidaS(stemp)){

    Pop(stemp,el);
    Push(s,el);

  }
  free(el);

if(id)
  	return id;

return N-1;
}
//aflu timpul maxim ramas din coada
int maxtime(void*c){
	void *qtemp=InitQ(DimEQ(c),MAX);

  void *el=malloc(DimEQ(c));
  int max=0;
  while(!VidaQ(c)){
    ExtrQ(c,el);
   	if(((Task*)el)->time > max)
   		max=((Task*)el)->time;
    IntrQ(qtemp,el);

  }

  ConcatQ(c,qtemp);



  return max;
}

int run(void*s,void*q1,void*q2,void*q3,int time,int N,int cuanta,int executed){

  void *el=malloc(DimEQ(q2));
  
  int i=N;
  //daca coada de running e goala atunci inserez N elemente in ordine in ea si in stiva
  if(NrEQ(q2)==0){

  	while(NrEQ(q2)!=N && !VidaQ(q1) ){
  		
  		ExtrQ(q1,el);
  		
  		Thread x;
		x.th_id =i-1;
		x.task_id=((Task*)el)->id;

  		((Task*)el)->th_id=i;

  		i--;
  		insertsort(q2,el);


    	Push(s,&x);
    

  	}}
//daca timpul este mai mare decat cuanta atunci verific coada daca trebuie sa bag elemente in coada de finished sau
// sa actualizez timpul
  	if(time > cuanta)
  		while(time>cuanta){
  			time-=cuanta;
  			if(!VidaQ(q2)){
  			executed+=cuanta > maxtime(q2)? maxtime(q2) : cuanta ;
  		
  	}
  	void *qtemp2=InitQ(DimEQ(q1),MAX);
  
  while(!VidaQ(q2)){
   ExtrQ(q2,el);
   
    if(((Task*)el)->time <= cuanta ){
   	
    	IntrQ(q3,el);
    	//scot elementul cu acelasi id ca elementul care a fost bagat in coada de finished
    	Popspecial(s,((Task*)el)->id);
    	Thread x;
    	x.th_id=0;
    	x.task_id=0;
    	Push(s,&x);
    	
    }
    else {
    	((Task*)el)->time -=cuanta;
    	insertsort(qtemp2,el);
    }
    

  }

  


  ConcatQ(q2,qtemp2);

  	//daca coada running nu are N elemente atunci o umplu pana cand indeplinesc acea conditie
if(NrEQ(q2)!=N)
  	while(NrEQ(q2)!=N && !VidaQ(q1) ){
  		
  		ExtrQ(q1,el);
  		
  		insertsort(q2,el);
  		Thread x;
    	x.task_id=((Task*)el)->id;
  		x.th_id=PrimulThvalabil(s,N);
    
    	Push(s,&x);
   
  	}


  }
//daca timpul este mai mic decat cuanta atunci trebuie sa verific elementele din coada in functie de timp 
  // similar ca mai sus
  if(time <= cuanta){

  	if( !VidaQ(q2)){
  			//adaug la timpul de pt comanda finished minimul dintre time si timpul maxim ramas  din coada
  			executed += time > maxtime(q2)? maxtime(q2) : time ;
  			
  		} 
  			
  	
  	void *qtemp2=InitQ(DimEQ(q1),MAX);
  
  while(!VidaQ(q2)){
   ExtrQ(q2,el);
   
    if(((Task*)el)->time <= time ){
   	
    	IntrQ(q3,el);
    	Popspecial(s,((Task*)el)->id);
    	Thread x;
    	x.th_id=0;
    	x.task_id=0;
    	Push(s,&x);
    	
    }
    else {
    	((Task*)el)->time -=time;
    	insertsort(qtemp2,el);
    }
    

  }

  


  ConcatQ(q2,qtemp2);

  	
if(NrEQ(q2)!=N)
  	while(NrEQ(q2)!=N && !VidaQ(q1) ){
  		
  		ExtrQ(q1,el);
  		
  		insertsort(q2,el);
  		Thread x;
    	x.task_id=((Task*)el)->id;
  		x.th_id=PrimulThvalabil(s,N);
    
    	Push(s,&x);
   
  	}


  }
return executed;


}


int finished(void*s,void*q1,void*q2,void*q3,int fin,int N){
 
 
 void *el=malloc(DimEQ(q2));
 int max=0;
 


 int ok=0;
 //cat timp coada waiting nu e goala introduc N elemente in coada de running
 	while(ok==0){
 		max=0;
 	while(NrEQ(q2)!=N && !VidaQ(q1) ){
  		
  		ExtrQ(q1,el);
  	
  		insertsort(q2,el);

  	}
  	//iau maximul de timp ramas din coada de running
  	while(!VidaQ(q2)){
   ExtrQ(q2,el);
   
    if(((Task*)el)->time > max )
   	
    max=((Task*)el)->time;

	}
	 fin+=max;



	 if(VidaQ(q1))
	 	ok=1;

	}



 return fin;

}

int main(int argc, char** argv)
{


	int finish=0;
	FILE *fp;
	 fp = fopen(argv[2], "w+");
	FILE *f;
	char * line = NULL;
	size_t len = 0;


	f = fopen(argv[1], "rt");
	if (f == NULL)
		return 0;

	
	getline(&line, &len, f);
	int Q=atoi(line);

	getline(&line, &len, f);
	int C=atoi(line);

void *q1, *s,*q2,*q3;


  	q1 = InitQ(sizeof(Task),MAX);
	if (!q1)
		return 1;

  	s = InitS(sizeof(Task),2*C);
	if (!s)
	{
		DistrQ(&q1);
		return 1;
	}

	q2 = InitQ(sizeof(Task),2*C);
	if (!q2){
		DistrS(&s);
		DistrQ(&q1);
		return 1;
	}

	q3 = InitQ(sizeof(Task),MAX);
	if (!q3){
		DistrS(&s);
		DistrQ(&q2);
		DistrQ(&q1);
		return 1;
	}

	
	


	while (getline(&line, &len, f) != -1) {
		

		

		if( strstr(line,"add_tasks")){

			

			char * value1 = strtok(line, " ");
		
			value1=strtok(NULL, " ");
			char * value2 = strtok(NULL, " ");
			char * value3 = strtok(NULL, " ");




			if (value3[strlen(value3) - 1] == '\n')
				value3[strlen(value3) - 1] = '\0';
			int i;
					for( i=0;i<atoi(value1);i++){
						//creez un element de tip Task si ii adaug informatiile in el pt a-l introduce in coada de waiting
						Task c;
						c.priority=atoi(value3);
						c.time=atoi(value2);
						c.id=getFirstId(q1,2*C,q2);
						c.executed=atoi(value2);
						c.th_id=-1;
						
						
						insertsort(q1,&c);
						
						fputs("Task created successfully : ID ",fp);
						char  x [30];
						sprintf(x, "%d", c.id);
						fputs(x,fp);
						fputs(".\n",fp);
					}

    
			}

			if( strstr(line,"get_task")){
				char * value1 = strtok(line, " ");
		
				value1=strtok(NULL, " ");
				if (value1[strlen(value1) - 1] == '\n')
				value1[strlen(value1) - 1] = '\0';

				//verific daca se afla un id in q1 si q2 cu aceeasi functie
				//pt q3 daca am gasit un id il printez pe primul

				if(checktask(q2,atoi(value1))){
					char  x [30];
						sprintf(x, "%d", checktask(q2,atoi(value1)));
						
					fputs("Task ",fp);
					fputs(value1,fp);
					fputs(" is running (remaining_time = ",fp);
					fputs(x,fp);
					fputs(").\n",fp);
					continue;

				}
				else
					if(checktask(q1,atoi(value1))){
					char  x [30];
						sprintf(x, "%d", checktask(q1,atoi(value1)));
						
					fputs("Task ",fp);
					fputs(value1,fp);
					fputs(" is waiting (remaining_time = ",fp);
					fputs(x,fp);
					fputs(").\n",fp);
					continue;

				}
				else
					if(checktask3(q3,atoi(value1))){
					char  x [30];
						sprintf(x, "%d",checktask3(q3,atoi(value1)));
						
					fputs("Task ",fp);
					fputs(value1,fp);
					fputs(" is finished (executed_time = ",fp);
					fputs(x,fp);
					fputs(").\n",fp);
					continue;

				}
				else
					{
					
					fputs("Task ",fp);
					fputs(value1,fp);
					fputs(" not found.",fp);
					
					fputs("\n",fp);
					continue;

				}




			}


			if( strstr(line,"get_thread")){
				char * value1 = strtok(line, " ");
		
				value1=strtok(NULL, " ");
				if (value1[strlen(value1) - 1] == '\n')
				value1[strlen(value1) - 1] = '\0';

				if(atoi(value1) >= 2*C)
					continue;


				//verific daca threadul cu idul value1 exista , daca da ii iau valoarea taskului din q2
				if(returnthread(s,atoi(value1),2*C)){
					char  x [30];
						sprintf(x, "%d",checktask(q2,atoi(value1)));
						char  x1 [30];
						sprintf(x1, "%d",returnthread(s,atoi(value1),2*C));

						
					fputs("Thread ",fp);
					fputs(value1,fp);
					fputs(" is running task ",fp);
				
					fputs(x1,fp);
					fputs("(remaining_time= ",fp);
					fputs(x,fp);
					fputs(").\n",fp);
					continue;

				}
				else{
					fputs("Thread ",fp);
					fputs(value1,fp);
					fputs(" is idle.\n",fp);


				}
			}
			if( strstr(line,"print")){
				char * value1 = strtok(line, " ");
		
				value1=strtok(NULL, " ");
				if (value1[strlen(value1) - 1] == '\n')
				value1[strlen(value1) - 1] = '\0';
		

				if(strcmp("waiting",value1)==0){
					fputs("====== Waiting queue =======\n[",fp);
					if(NrEQ(q1)==0){
						fputs("]\n",fp);
						continue;
					}
					  void *qtemp=InitQ(DimEQ(q1),MAX);
					  void *el=malloc(DimEQ(q1));
					  // printez primele size(q1)-1 elemente deoarece la ultimul element printez si caracterul ']'
					  while(NrEQ(q1)!=1){
					    ExtrQ(q1,el);
					   	
					    fputs("(",fp);
					    char  x [30];
						sprintf(x, "%d",((Task*)el)->id);
						char  x1 [30];
						sprintf(x1, "%d",((Task*)el)->priority);
						char  x2 [30];
						sprintf(x2, "%d",((Task*)el)->time);
					    fputs(x,fp);
					    fputs(": priority = ",fp);
					    fputs(x1,fp);
					    fputs(", remaining_time = ",fp);
					    fputs(x2,fp);
					    fputs("),\n",fp);

					      
					    IntrQ(qtemp,el);

					  }

					  ExtrQ(q1,el);
					  fputs("(",fp);
					    char  x [30];
						sprintf(x, "%d",((Task*)el)->id);
						char  x1 [30];
						sprintf(x1, "%d",((Task*)el)->priority);
						char  x2 [30];
						sprintf(x2, "%d",((Task*)el)->time);
					    fputs(x,fp);
					    fputs(": priority = ",fp);
					    fputs(x1,fp);
					    fputs(", remaining_time = ",fp);
					    fputs(x2,fp);
					    fputs(")]\n",fp);
					    IntrQ(qtemp,el);

					  ConcatQ(q1,qtemp);

					continue;


				}


				if(strcmp("running",value1)==0){
					

					fputs("====== Running in parallel =======\n[",fp);
					if(VidaQ(q2)){
						fputs("]\n",fp);
						continue;
					}
					
					  void *qtemp=InitQ(DimEQ(q2),MAX);
					  void *el=malloc(DimEQ(q2));
					  // printez primele size(q2)-1 elemente deoarece la ultimul element printez si caracterul ']'
					  while(NrEQ(q2)!=1){
					    ExtrQ(q2,el);
					  
					    fputs("(",fp);
					    char  x [30];
						sprintf(x, "%d",((Task*)el)->id);
						char  x1 [30];
						sprintf(x1, "%d",((Task*)el)->priority);
						char  x2 [30];
						sprintf(x2, "%d",((Task*)el)->time);
						
						char  x3 [30];
						sprintf(x3, "%d",((Task*)el)->th_id);

					    fputs(x,fp);
					    fputs(": priority = ",fp);
					    fputs(x1,fp);
					    fputs(", remaining_time = ",fp);
					    fputs(x2,fp);
					    fputs(", running_thread = ",fp);
					    fputs(x3,fp);
					    fputs("),\n",fp);

					      
					    IntrQ(qtemp,el);

					  }

					  ExtrQ(q2,el);
					  fputs("(",fp);
					    char  x [30];
						sprintf(x, "%d",((Task*)el)->id);
						char  x1 [30];
						sprintf(x1, "%d",((Task*)el)->priority);
						char  x2 [30];
						sprintf(x2, "%d",((Task*)el)->time);
						
						char  x3 [30];
						sprintf(x3, "%d",((Task*)el)->th_id);
					    fputs(x,fp);
					    fputs(": priority = ",fp);
					    fputs(x1,fp);
					    fputs(", remaining_time = ",fp);
					    fputs(x2,fp);
					    fputs(", running_thread = ",fp);
					    fputs(x3,fp);
					    fputs(")]\n",fp);
					    IntrQ(qtemp,el);

					  ConcatQ(q2,qtemp);

					continue;


				}

				if(strcmp("finished",value1)==0){

					fputs("====== Finished queue =======\n[",fp);
					if(VidaQ(q3)){
						fputs("]\n",fp);
						continue;
					}
					
					  void *qtemp=InitQ(DimEQ(q3),MAX);
					  void *el=malloc(DimEQ(q3));
					  
					  // printez primele size(q3)-1 elemente deoarece la ultimul element printez si caracterul ']'
					  while(NrEQ(q3)!=1){
					    ExtrQ(q3,el);
					   	
					    fputs("(",fp);
					    char  x [30];
						sprintf(x, "%d",((Task*)el)->id);
						char  x1 [30];
						sprintf(x1, "%d",((Task*)el)->priority);
						char  x2 [30];
						sprintf(x2, "%d",((Task*)el)->executed);
					    fputs(x,fp);
					    fputs(": priority = ",fp);
					    fputs(x1,fp);
					    fputs(", executed_time = ",fp);
					    fputs(x2,fp);
					    fputs("),\n",fp);

					      
					    IntrQ(qtemp,el);

					  }

					  ExtrQ(q3,el);
					  fputs("(",fp);
					    char  x [30];
						sprintf(x, "%d",((Task*)el)->id);
						char  x1 [30];
						sprintf(x1, "%d",((Task*)el)->priority);
						char  x2 [30];
						sprintf(x2, "%d",((Task*)el)->executed);
					    fputs(x,fp);
					    fputs(": priority = ",fp);
					    fputs(x1,fp);
					    fputs(", executed_time = ",fp);
					    fputs(x2,fp);
					    fputs(")]\n",fp);
					    IntrQ(qtemp,el);

					  ConcatQ(q3,qtemp);
					  continue;


				}

			}


			if( strstr(line,"run")){
				char * value1 = strtok(line, " ");
		
				value1=strtok(NULL, " ");
				if (value1[strlen(value1) - 1] == '\n')
				value1[strlen(value1) - 1] = '\0';

			fputs("Running tasks for ",fp);
			fputs(value1,fp);
			fputs(" ms...\n",fp);
			
			//adaug in finish timpu de rulare pt run
			finish=run(s,q1,q2,q3,atoi(value1),2*C,Q,finish); 

			

			}

			if ( strstr(line,"finish")){
				
			//adaug in finish timpul de rulare pt finish
			finish=finished(s,q1,q2,q3,finish,2*C);

			char  x [30];
			sprintf(x, "%d",finish);

			fputs("Total time: ",fp);
			fputs(x,fp);
			

			}

	
    }


	fclose(f);
	fclose(fp);

  return 0;
}
