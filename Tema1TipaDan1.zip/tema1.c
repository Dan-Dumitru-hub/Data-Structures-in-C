//TIPA Dan-Dumitru gr343C3

#include <stdio.h>
#include "tlg.h"
#include "thash.h"
#include <string.h>

#include <stdlib.h>
#include <ctype.h> 

typedef struct {
	char key[50];

	int aparitii;
} Tema1;//structura in care salvez cuvantul si nr de aparitii




int codHash(void* element){
	Tema1 * new = (Tema1 *) element;
	 char  result;

    
    result = tolower(new->key[0]);
    
	return result-'a';
	
}

//functie de comparatie  dupa aparitii si dupa lexicografic
int cmpel(void * element , void *element1)
{
	Tema1 * new = (Tema1 *) element;
	int  value = new->aparitii;
	Tema1 * new1 = (Tema1 *) element1;
	int  value1 = new1->aparitii;
	if(value !=value1)
		return value-value1;
	return strcmp(new1->key,new->key);
}


//functie cu care creez o celula care o sa fie pusa in continuarea unei liste verticale/in jos
TLG  alocCelulaInJos(char * x){
	
	TLG aux= (TLG) calloc(sizeof(TCelulaG),1);
	if(!aux)
		return NULL;
	
	Tema1 * y=calloc(sizeof(Tema1),1);
	if(!y)
		return NULL;

	y->aparitii=1;
	strcpy(y->key,x);
	aux->info=y;
	aux->urm=NULL;
	return aux;

}
//functie cu care creez o celula care reprezinta capul de lista unde lungimea cuvantului este egal cu numarul de apartii
TLG  alocCelulaLaDreapta(char * x){
	
	TLG aux= (TLG) calloc(sizeof(TCelulaG),1);
	if(!aux)
		return NULL;
	
	Tema1 * y=calloc(sizeof(Tema1),1);
	if(!y)
		return NULL;

	y->aparitii=strlen(x);
	strcpy(y->key,"\0");
	aux->info=y;
	aux->nextaparitii=NULL;
	aux->urm=alocCelulaInJos(x);
	return aux;

}



int main(int argc, char** argv)
{

	
	char filein=*argv[1];
	
	FILE *fp;
	 
	FILE *f;
	char * line = NULL;
	size_t len = 0;
	TLG L = NULL;

	f = fopen(argv[1], "rt");
	if (f == NULL)
		return 0;

	TH *h = NULL;
	
   
	int rez;

	
	size_t M = 26;

	//initializare tabela hash
	h = (TH *) IniTH(M, codHash);
	if(h == NULL)
		return 0;



	while (getline(&line, &len, f) != -1) {

		if( strstr(line,"print")){

			char *copy = strdup(line);
			char * value2 = strtok(copy, " .,");
			char *value =calloc(sizeof(int),1) ;

			
			value2=strtok(NULL, " .,");
			
			if(value2 !=NULL)
			strcpy(value,value2);
			value2=strtok(NULL, " .,");

			//daca am 2 parametrii atunci salvez in value2 al doilea parametru si in value primul parametru
			if(value2 && value){
				

			TLG el2,p,el;

			char  result;

    
    		result = tolower(value[0]);
        p = h->v[result -'a'];//iau lista care are litera value
        if(p) {
        	
        	for( el2=p;el2!=NULL;el2=el2->nextaparitii)
        		if(atoi(value2)==((Tema1 *)(el2->info))->aparitii){

        		//daca capul de lista are numaru de aparitii la fel ca al doilea parametru inseamna ca tre sa printez acea lista

        		printf("(%d:",((Tema1 *)(el2->info))->aparitii);
            for(el = el2->urm; el->urm != NULL; el = el->urm){
            	printf("%s/%d, ",((Tema1 *)(el->info))->key,((Tema1 *)(el->info))->aparitii);
               
          		}
          	printf("%s/%d)",((Tema1 *)(el->info))->key,((Tema1 *)(el->info))->aparitii);
          	printf("\n");
           	}
          
           
        	}


			}//daca am un singur parametru
			
			else if(atoi(value)>0 ){

			TLG el2,p,el;
			TLG el3,p1,el4;
    		int i;
        for( i = 0; i < h->M; i++) {

        p = h->v[i];
        int nuexistacapdelista=1;


        for( el3=p;el3!=NULL;el3=el3->nextaparitii)
        	
            for(el4 = el3->urm; el4 != NULL; el4 = el4->urm)
            	if(((Tema1 *)(el4->info))->aparitii<=atoi(value))
            		nuexistacapdelista=0;
            	//verific daca exista un cap de lista care are un element care are nr de aparitii mai mic decat value
            	


        if(nuexistacapdelista==0) {
        	printf("pos%d: ",i);
        	for( el2=p;el2!=NULL;el2=el2->nextaparitii)
        		
        		{ int nuexistalistainjos=1;

        			for(el4 = el2->urm; el4 != NULL; el4 = el4->urm)
            	if(((Tema1 *)(el4->info))->aparitii<=atoi(value))
            		nuexistalistainjos=0;
            	//verific daca exista un element in lista care are nr aparitii < value
            	if(nuexistalistainjos==1)
            		continue;



        		printf("(%d: ",((Tema1 *)(el2->info))->aparitii);
            for(el = el2->urm; el->urm != NULL; el = el->urm){
            	if(((Tema1 *)(el->info))->aparitii<=atoi(value))
            	printf("%s/%d, ",((Tema1 *)(el->info))->key,((Tema1 *)(el->info))->aparitii);
               
            	
            	
            
          }
          if(((Tema1 *)(el->info))->aparitii<=atoi(value))//verific ultimul element
          	printf("%s/%d)",((Tema1 *)(el->info))->key,((Tema1 *)(el->info))->aparitii);
      		else
      			printf(")");

           		}
          
           printf("\n");
        }



			}}
			else
			 {



			TLG el2,p,el;
			int i;
for( i = 0; i < h->M; i++) {

        p = h->v[i];
        if(p) {
        	printf("pos %d: ",i);
        	for( el2=p;el2!=NULL;el2=el2->nextaparitii){
        		printf("(%d:",((Tema1 *)(el2->info))->aparitii);

            for(el = el2->urm; el->urm != NULL; el = el->urm){
            	printf("%s/%d, ",((Tema1 *)(el->info))->key,((Tema1 *)(el->info))->aparitii);
               
          		}
          	printf("%s/%d)",((Tema1 *)(el->info))->key,((Tema1 *)(el->info))->aparitii);

           }
          
           printf("\n");
        }

	}	


			}}

	

		if( strstr(line,"insert")){
			int ok=1;
			
			char *copy = strdup(line);
			char * value = strtok(copy, " .,");
			while (ok==1){

			
			value=strtok(NULL, " .,");
			if (value == NULL)
				break;
			
			if(value == "\n")
				continue;
			if(strlen(value)<3)
				continue;

		if (value[strlen(value) - 1] == '\n')
			value[strlen(value) - 1] = '\0';

		


		 TLG p, el;
		 int k=0;
		   int i;
		   Tema1 * new = (Tema1 *)calloc(sizeof(Tema1),1);//creez elementul pt a vedea daca se afla deja in tabela hash
		if (new == NULL)
			break;

		strcpy(new->key, value);
		
		new->aparitii=1;
		

	
		int cod = h->fh(new), rez;
		free(new);
		
		int j=1;
		int existaladreapta=0;
		
        p = h->v[cod];
        if(p==NULL) 
        //daca nu am niciun cap de lista,nicio celula pentru lista care se duce in dreapta
        {
        	h->v[cod]=alocCelulaLaDreapta(value);
        	

        }
        else
        {

        	int length=strlen(value);//iau lungimea cuvantului

        	TLG el=p;
        	//tre sa vad daca exista in jos , nu exista la dreapta
        	for(;el!=NULL;el=el->nextaparitii) 
        			if(((Tema1 *)(el->info))->aparitii == length  ){

        			//daca nr de aparitii al capului de lista == lungimea cuvantului inseamna ca exista o lista in care sal inserez
        			existaladreapta=1; 
        				break;}


        	
        	if(existaladreapta==0){

        	if(((Tema1 *)(p->info))->aparitii > length){ // tre sa bag un nou cap de lista, pe orzintala
        		
        		TLG aux=alocCelulaLaDreapta(value);
        		aux->nextaparitii=p;
        		//noul cap de lista o sa fie pus ordonat in stanga deoarece are nr de aparitii mai mic decat prima celula
        		h->v[cod]=aux;

        		
        	}
        	else{//altfel fac un cap de lista nou si il inserez ordonat la final sau la mijloc
        		TLG el=p,ant=NULL;

        		for(;el!=NULL;ant=el,el=el->nextaparitii){ 
        			if(((Tema1 *)(el->info))->aparitii > length  ){ 
        				break;}


        		}
        		TLG aux=alocCelulaLaDreapta(value);
        		

        		aux->nextaparitii=el;
        		
        			
        		
        		ant->nextaparitii=aux;
        		
        		
        		

        	    }	
        	

		
			}
			else{
				


			///exista la dreapta trebuie sa vad daca exista cuvantu 
				TLG el=p,el1;
				int gasit=0;
				for(;el!=NULL;el=el->nextaparitii){
				  
        			if(((Tema1 *)(el->info))->aparitii == length  ){


        				for(el1 = el->urm; el1!=NULL; el1 = el1->urm){
        					
        					if(strcmp ( ((Tema1 *)(el1->info))->key , value)==0){
        					//daca cuvantu exista deja ii cresc nr de aparitii
        						gasit=1;
        						
        						((Tema1 *)(el1->info))->aparitii +=1;
        						break;
        						

        					}

        				}
        				if(gasit==0){//daca nu il inserez la finalul listei
        					

        					TLG aux= alocCelulaInJos(value);


        					for(el1 = el->urm; el1->urm!=NULL; el1 = el1->urm)//inserez la final
        						gasit=0;
        					el1->urm=aux;

        				}

        				


        	
        				} }
				

				}


        }
  		 

    
		}
TLG el2,p,el,el1; // sortez celulele dupa functia de comparatie
int i;
for( i = 0; i < h->M; i++) {
        p = h->v[i];
        if(p) {
        	for( el2=p;el2!=NULL;el2=el2->nextaparitii)
            for(el = el2->urm; el->urm != NULL; el = el->urm){
            	
               for( el1 = el->urm; el1!=NULL; el1 = el1->urm)
            	if(cmpel( ((Tema1 *)(el1->info)) , ((Tema1 *)(el->info)) ) >0)
            	{ 

            		char aux[50];
            		strcpy(aux,(((Tema1 *)(el->info))->key));
            		strcpy(((Tema1 *)(el->info))->key,((Tema1 *)(el1->info))->key);
            		strcpy(((Tema1 *)(el1->info))->key,aux);
            		int aparitii;
            		aparitii=(((Tema1 *)(el->info))->aparitii);
            		((Tema1 *)(el->info))->aparitii=(((Tema1 *)(el1->info))->aparitii);
            		(((Tema1 *)(el1->info))->aparitii)=aparitii;
            		
            		
            		
            		
            		
            	}
            	
            
          } 
          

        }

    }









		}//se termina insert





			
    }



        	

	fclose(f);
	


  return 0;
}
