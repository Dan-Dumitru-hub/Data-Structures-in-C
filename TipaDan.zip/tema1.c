//TIPA Dan-Dumitru gr335CB
#include <stdio.h>
#include "tlg.h"
#include "thash.h"
#include <string.h>

#include <stdlib.h>

typedef struct {
	char key[50];
	char value[50];
	int m;
	
} Tema1;//structura in care salvez cheia si value si M



int codHash(void * element)
{
	Tema1 * new = (Tema1 *) element;
	char * value = new->key;
	int suma=0;
	int i;
	for( i=0;i<strlen(value);i++){
suma+=value[i];
	}
	return suma%(new->m);
}//functie cu care aflu in ce bucket se afla elementul



//functie de comparatie  dupa key

int cmpel(void * element , void *element1)
{
	Tema1 * new = (Tema1 *) element;
	char * value = new->key;
	Tema1 * new1 = (Tema1 *) element1;
	char * value1 = new1->key;
	
	return strcmp(value,value1);
}


//functie de eliminare element
void removeTh(char *value , TH *h){

if (value[strlen(value) - 1] == '\n')
			value[strlen(value) - 1] = '\0';


		   TLG p, el;
		   int i;
		   int k=0;

		for(i = 0; i < h->M; i++)//parcurg toate listele
		{
        p = h->v[i];
        
        k=0;
        if(p) {//daca p exista mai intai verific daca este format dintrun singur element
        	if(p->urm==p && strcmp(value,((Tema1 *)(p->info))->key)==0 ){

        	p=NULL;
        	
        	k=1;
        }
        int j=1;
            if(k==0)//daca nu incep sa iterez prin lista si sa caut elementul de sters
            for(el = p;j<3; el = el->urm){
            	if(el==p)
            		j++;
             
            	if(strcmp(value,((Tema1 *)(el->info))->key)==0){
            		
            		el->urm->pre=el->pre;
            		el->pre->urm=el->urm;

            		if( h->v[i]==el){//resetez h->v[i]
            			 h->v[i]=el->urm;

            		}

            		
            		free(el);
            		break;
   
            		
 
            	}
            }
            if(k==1){p=h->v[i];//daca este singur in lista ii dau free

            	h->v[i]=NULL;
            	free(p);
            }
            
           
        }



    }


    
	



}

int main(int argc, char** argv)
{

	int M1=atoi(argv[1]);
	char filein=*argv[2];
	char fileout=*argv[3];
	FILE *fp;
	 fp = fopen(argv[3], "w+");
	FILE *f;
	char * line = NULL;
	size_t len = 0;
	TLG L = NULL;

	f = fopen(argv[2], "rt");
	if (f == NULL)
		return 0;

	TH *h = NULL;
	
   
	int rez;

	
	size_t M = M1;

	//initializare tabela hash
	h = (TH *) IniTH(M, codHash);
	if(h == NULL)
		return 0;



	while (getline(&line, &len, f) != -1) {
		TLG el1;

		

		if( strstr(line,"put")){

			char *copy = strdup(line);
			
		char * value = strtok(copy, " ");
		
				value=strtok(NULL, " ");
		char * key = strtok(NULL, " ");



		

		if (key[strlen(key) - 1] == '\n')
			key[strlen(key) - 1] = '\0';


		 TLG p, el;
		 int k=0;
		   int i;
		   Tema1 * new = malloc(sizeof(Tema1));//creez elementul pt a vedea daca se afla deja in tabela hash
		if (new == NULL)
			break;

		strcpy(new->key, value);
		strcpy(new->value, key);
		new->m=atoi(argv[1]);

		 
       

	
		int cod = h->fh(new), rez;
		
		{
        p = h->v[cod];
        if(p) {
        	int j=0;
        	
            for(el = p; j<2; el = el->urm){
               if(el==p)
               	j++;
            	if(strcmp(value,((Tema1 *)(el->info))->key)==0)//daca exista dau break
            	{
            		
            		k=1;
            		break;
            		
            		
            		
            	}
            }
           
        }
    }




    	if(k==0){//daca nu exista il inserez in tabela
		Tema1 * new = malloc(sizeof(Tema1));
		if (new == NULL)
			break;

		strcpy(new->key, value);
		strcpy(new->value, key);
		new->m=atoi(argv[1]);

		 
       

	
		 	  int cod = h->fh(new), rez;
    TLG el;
    
     
    
    rez = InsLG(&h->v[cod], new);
   


        if(!rez) {
						free(new);
						return 0;
		}
		 
	
		}





//sortez tabela hash dupa cheie

 TLG el1;

		 
		for(i = 0; i < h->M; i++) {
        p = h->v[i];
        if(p) {int j=0;
        	
            for(el = p; j<2; el = el->urm){
            	if(el==p)
            		j++;
               for(el1 = el->urm; el1!=p; el1 = el1->urm)
            	if(cmpel( ((Tema1 *)(el->info)) , ((Tema1 *)(el1->info)) ) >=0)
            	{ 

            		char aux[50];
            		strcpy(aux,(((Tema1 *)(el->info))->key));
            		strcpy(((Tema1 *)(el->info))->key,((Tema1 *)(el1->info))->key);
            		strcpy(((Tema1 *)(el1->info))->key,aux);
            		
            		strcpy(aux,(((Tema1 *)(el->info))->value));
            		strcpy(((Tema1 *)(el->info))->value,((Tema1 *)(el1->info))->value);
            		strcpy(((Tema1 *)(el1->info))->value,aux);
            		
            		
            		
            		
            	}
            	
            
          } 
          

        }

    }
    
		}



	if( strstr(line,"print_bucket")){
char *copy = strdup(line);
char * value = strtok(copy, " ");
value=strtok(NULL, " ");


 TLG p, el;

 
		 
		
    
		   int i=atoi(value);
		   if(i>M-1){
		   	
		   	continue;
		   }

		{
        p = h->v[i];
        if(p) {
        	
			char str[12];
			sprintf(str, "%d", i);
           	int j=1;//iterez prin lista 
            for(el = p; j<2; el = el->urm)
               
            	{if(el==p->pre)
            		j++;
            		fputs(((Tema1 *)(el->info))->value,fp);
            		fputs(" ",fp);
            		
            		
            	}
           
            	fputs("\n",fp);
           
        }
        else {
        	fputs("VIDA\n",fp);

        }
    }







	}
	else if( strstr(line,"print")){


		   TLG p, el;
		   int i;

 			TLG el1;

		 //sortare
		for(i = 0; i < h->M; i++) {
        p = h->v[i];
        if(p) {int j=0;
        	
            for(el = p; j<2; el = el->urm){
            	if(el==p->urm)
            		j++;
               for(el1 = el->urm; el1!=p; el1 = el1->urm)
            	if(cmpel( ((Tema1 *)(el->info)) , ((Tema1 *)(el1->info)) ) >=0)
            	{ 

            		char aux[50];
            		strcpy(aux,(((Tema1 *)(el->info))->key));
            		strcpy(((Tema1 *)(el->info))->key,((Tema1 *)(el1->info))->key);
            		strcpy(((Tema1 *)(el1->info))->key,aux);
            		
            		strcpy(aux,(((Tema1 *)(el->info))->value));
            		strcpy(((Tema1 *)(el->info))->value,((Tema1 *)(el1->info))->value);
            		strcpy(((Tema1 *)(el1->info))->value,aux);
            		
            		
            		
            		
            	}
            	
            
          } 
          

        }

    }
    




		for(i = 0; i < h->M; i++) {
        p = h->v[i];
        if(p) {
        	
			char str[12];
			sprintf(str, "%d", i);
            fputs(str,fp);
            fputs(": ",fp);
            int j=1;
            for(el = p; j<2; el = el->urm)//iterez prin lista pt a printa
             
            	{if(el==p->pre)
            		j++;
            		fputs(((Tema1 *)(el->info))->value,fp);
            		fputs(" ",fp);
            		
            		
            	}
            
            	fputs("\n",fp);
           
        }
    }






	}


if( strstr(line,"get")){
char *copy = strdup(line);
char * value = strtok(copy, " ");
value=strtok(NULL, " ");
int k=0;
int s=0;

//scot /n in caz daca exita
	if (value[strlen(value) - 1] == '\n')
		value[strlen(value) - 1] = '\0';


		   TLG p, el;
		   int i;


		
		
		   Tema1 * new = malloc(sizeof(Tema1));
		if (new == NULL)
			break;

		strcpy(new->key, value);
		
		new->m=atoi(argv[1]);

		 
       

	
		 int cod = h->fh(new);
		{
        p = h->v[cod];//dupa ce am aflat in ce bucket ar putea fi acel key incep sa caut in lista
        if(p) {
           int j=0;
            
            for(el = p;j<2; el = el->urm){
           if(el==p)
           	j++;
            	if(strcmp(value,((Tema1 *)(el->info))->key)==0){
            		fputs(((Tema1 *)(el->info))->value,fp);
            		fputs("\n",fp);
            		
            		s=1;
            		break;
            	}}
           
           
        }
    }
if(s==0)
	fputs("NULL\n",fp);


	}

	if( strstr(line,"remove")){
		


char *copy = strdup(line);
char * value = strtok(copy, " ");
value=strtok(NULL, " ");

removeTh(value,h);


	}
	

	if( strstr(line,"find")){

char *copy = strdup(line);
char * value = strtok(copy, " ");
value=strtok(NULL, " ");
int k=0;

if (value[strlen(value) - 1] == '\n')
			value[strlen(value) - 1] = '\0';


		   TLG p, el;
		   int i;
		   Tema1 * new = malloc(sizeof(Tema1));
			if (new == NULL)
			break;

		strcpy(new->key, value);
		
		new->m=atoi(argv[1]);

		 	  int cod = h->fh(new);//in cod salvez indicele pt in care lista sa ma uit

		 {
        p = h->v[cod];
        if(p) {int j=0;
            
            for(el = p; j<2; el = el->urm){
               if(el==p)
               	j++;
            	if(strcmp(value,((Tema1 *)(el->info))->key)==0){
            		fputs("True\n",fp);
            		k=1;
            		break;
            	}}
          
           
        }
    }
if(k==0)
	fputs("False\n",fp);

	}
    }


	fclose(f);
	fclose(fp);







  return 0;
}
