//TIPA Dan-Dumitru gr335CB
#include "tlg.h"

int InsLG(TLG* aL, void* ae)
{
	if(*aL==NULL){
		TLG aux =(TLG) malloc(sizeof(TLG));
		
		if(!aux)
			return 0;
		aux->info=ae;
		aux->urm=aux;
		aux->pre=aux;
		*aL=aux;
		return 1;
		


	}
	
	TLG aux = malloc(sizeof(TCelulaG));
	if(!aux)
	    return 0;



	aux->info = ae;
	aux->pre = *aL;
	aux->urm = (*aL)->urm;
	
	(*aL)->urm->pre=aux;
	
	(*aL)->urm=aux;
	return 1;

	
	

	
}
